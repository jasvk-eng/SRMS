import sqlite3

# Connect to the database (or create it if it doesn't exist)
db_file = "C:/Users/91820/Desktop/login-app/database/data.sqlite"  # Replace with your database file
connection = sqlite3.connect(db_file)

try:
    cursor = connection.cursor()

    # Example: Fetch data from a table
    query = "SELECT * FROM users;"  # Replace with your table name
    cursor.execute(query)

    # Fetch all rows
    rows = cursor.fetchall()

    # Print the rows
    print("Data from the database:")
    for row in rows:
        print(row)

except sqlite3.Error as e:
    print(f"Database error: {e}")

finally:
    # Close the connection
    connection.close()
