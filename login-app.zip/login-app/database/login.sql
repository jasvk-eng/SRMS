-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 27, 2024 at 05:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `student__c`
--

CREATE TABLE `student__c` (
  `id` int(11) NOT NULL,
  `Stu_Name` varchar(100) DEFAULT NULL,
  `Enrollment` varchar(17) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `Address` varchar(200) DEFAULT NULL,
  `Mobile_Number` varchar(10) DEFAULT NULL,
  `Parents_Mobile_Number` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student__c`
--

INSERT INTO `student__c` (`id`, `Stu_Name`, `Enrollment`, `email`, `DOB`, `Address`, `Mobile_Number`, `Parents_Mobile_Number`) VALUES
(1, 'Acharya Sneha Gauravbhai', '22190910010001', 'snehaachary2410@gmail.com', '2004-10-24', 'Ahmedabad', '8813561863', '9684683256'),
(2, 'Aditya Bhadauriya', '22190910010002', 'aditya658@gmail.com', '2004-02-09', 'Ahmedabad', '9574123036', '6874519753'),
(3, 'Chauhan Harikishan Ramkeshwar', '22190910010003', 'Harikishan687@gmail.com', '2005-10-18', 'Ahmedabad', '9587187453', '8267418589'),
(4, 'Chauhan Karan Rakeshbhai', '22190910010004', 'karanchauhan574@gmail.com', '2004-01-25', 'Ahmedabad', '8872351489', '6872354866'),
(5, 'Chauhan Kumkumben', '22190910010005', 'kumkumchauham1268@gmail.com', '2004-06-09', 'Ahmedabad', '9958416873', '8642770395'),
(6, 'Devani Ishan Mukeshbhai', '22190910010006', 'ishandevani3851@gmailcom', '2004-08-29', 'Ahmedabad', '6161358206', '9562347512'),
(7, 'Dharva Nidhi Chetankumar', '22190910010007', 'nidhidarva2040@gmail.com', '2004-02-04', 'Ahmedabad', '9933946616', '9027461052'),
(8, 'Gadhavi Janalba Rameshdan', '22190910010008', 'janalgadhavi6981@gmail.com', '2004-05-24', 'Ahmedabad', '8927129515', '9952674508'),
(9, 'Jadav Yash Hasamukbhai', '22190910010009', 'jashjadav8351@gmail.com', '2005-09-09', 'Ahmedabad', '6842729505', '9384623383'),
(10, 'khobragade Jiya Rahulkumar', '22190910010010', 'jiyakhobragade5872@gmail.com', '2004-03-01', 'Ahmedabad', '6335037415', '8657136820'),
(11, 'khonde Meetkumar prakash', '22190910010011', 'meetkhonde1502@gmail.com', '2004-05-18', 'Ahmedabad', '6823455235', '9742222013'),
(12, 'khubchandani Jitesh Prakash', '22190910010012', 'jitesh9999@gmail.com', '2004-02-25', 'Ahmedabad', '6826837985', '8658451513'),
(13, 'Makwana Aryan Baldevbhai', '22190910010013', 'jaryanmakwana686@gmail.com', '2004-05-30', 'Ahmedabad', '6846234152', '8628742238'),
(14, 'Mistri Parth Ashvinkumar', '22190910010014', 'parthmistri6871@gmail.com', '2005-05-12', 'Ahmedabad', '6971663202', '8451541210'),
(15, 'Solanki Nidhi ', '22190910010015', 'nidhi5745@gmail.com', '2004-06-29', 'Ahmedabad', '7784136512', '9778454206'),
(16, 'Panchal Amisha Rameshbhai', '22190910010016', 'amishapamchal8452@gmail.com', '2004-07-10', 'Ahmedabad', '7823522197', '8484548406'),
(17, 'Panchal krunal Bhadreshbhai', '22190910010017', 'krunalpanchal7885@gmail.com', '2004-12-27', 'Ahmedabad', '8946326649', '9324545462'),
(18, 'Panchal Vishakha Harshadhai', '22190910010018', 'vishakhapanchal2604@gmail.com', '2004-11-26', 'Ahmedabad', '9584632846', '6846398463'),
(19, 'Parikh Vedkumar Rameshbhai', '22190910010019', 'vedkumarparmar2654@gmail.com', '2004-02-10', 'Ahmedabad', '8236741586', '8441515036'),
(20, 'Patel Jinay Dhirajkumar', '22190910010024', 'jinaypatel15415@gmail.com', '2004-07-09', 'Ahmedabad', '9742681063', '4881888833'),
(21, 'Patel Kaushal Dineshbhai', '22190910010025', 'kaushalpatel1352@gmail.com', '2004-11-09', 'Ahmedabad', '9848415154', '9791464566'),
(22, 'Patel Kavanankumar Ghanshyambhai', '22190910010026', 'kavanpatel7894@gmail.com', '2004-03-30', 'Ahmedabad', '7548451503', '8594626236'),
(23, 'Patle Linaben Hasmukhbhai', '22190910010027', 'linapatrl6872@gmail.com', '2004-08-09', 'Ahmedabad', '7726831084', '7241151516'),
(24, 'Patel Namra Sudhirbhai', '22190910010028', 'namrapatel2571@gmail.com', '2005-07-16', 'Ahmedabad', '7529980365', '7845548452'),
(25, 'Patel Prakruti Chetanbhai', '22190910010029', 'prakrutipatel3751@gmail.com', '2004-03-09', 'Ahmedabad', '7841544621', '6978454515'),
(26, 'Patel Umang Rajeshbhai', '22190910010030', 'umangpatel7826@gmail.com', '2004-09-13', 'Ahmedabad', '9952254511', '9562622648'),
(27, 'Patel Devang Ganeshbhai', '22190910010031', 'devangpatil9672@gmail.com', '2005-08-08', 'Ahmedabad', '7845451519', '9785511545'),
(28, 'Prajapati Hitesh jagadishandhra', '22190910010032', 'hiteshprajati3752@gmail.com', '2004-05-09', 'Ahmedabad', '9452515435', '9725115111'),
(29, 'Pramar Kuldeep Jatinbhai', '22190910010033', 'kuldeeppramar3878@gmail.com', '2004-03-02', 'Ahmedabad', '9710054104', '9681050654'),
(30, 'Rana Harshvardhan Sureshbhai', '22190910010034', 'harshvardhan67415@gmail.com', '2005-08-22', 'Ahmedabad', '9784511136', '9744515112'),
(31, 'Raval Nisharg Ajaykumar', '22190910010035', 'nishargraval6752@gmail.com', '2004-03-09', 'Ahmedabad', '8485151156', '7852675590'),
(32, 'Saiyed Irfan Ilyas', '22190910010036', 'irfansaiyed6762@gmail.com', '2004-06-09', 'Ahmedabad', '9871828381', '9784652845'),
(33, 'Shaikh Mohd Aman Mustak Husain', '22190910010037', 'mohdamanshaikh5182@gmail.com', '2004-12-09', 'Ahmedabad', '7798626145', '9848967525'),
(34, 'Solanki Dimpal Kiranbhai', '22190910010038', 'dimpalsolnki4746@gmail.com', '2004-08-13', 'Ahmedabad', '9746226236', '7845451054'),
(35, 'Sorathiya Meet Sureshbhai', '22190910010039', 'meetsorathiya9746@gmail.com', '2005-11-09', 'Ahmedabad', '9974130300', '7484515110'),
(36, 'Suthar Dhrumi Mineshbhai', '22190910010040', 'dhrumisuthar3752@gmail.com', '2004-02-25', 'Ahmedabad', '9719826853', '9757141121'),
(37, 'Baraiya Tushar Khodsinh', '22190910010041', 'tusharbaraiya4856@gmail.com', '2004-08-16', 'Ahmedabad', '9794541132', '7445445154'),
(38, 'Darji Hitanshiben Rajendrakumar', '22190910010042', 'hitanshidarji1294@gmail.com', '2003-05-09', 'Ahmedabad', '9797448451', '8644541214'),
(39, 'Nagdev Tushar Anilkumar', '22190910010043', 'tusharnagdev6896@gmail.com', '2004-12-05', 'Ahmedabad', '9794121311', '7981211113'),
(40, 'Patle Astha Dipakkumar', '22190910010044', 'asthapatel8745@gmail.com', '2004-08-06', 'Ahmedabad', '9789545551', '7845152132'),
(41, 'Patle Dev Nayankumar', '22190910010045', 'devpatle6752@gmail.com', '2004-03-23', 'Ahmedabad', '9754125454', '7819262315'),
(42, 'Patle Meet Manubhai', '22190910010046', 'meetpatle3759@gmail.com', '2005-02-22', 'Ahmedabad', '9745121264', '7816181615'),
(43, 'Prajapati Jyoti Pavanbhai', '22190910010047', 'jyotiprajapati3751@gmail.com', '2004-01-29', 'Ahmedabad', '9794121974', '9954589451'),
(44, 'Prajapati Urvish Satishkumar', '22190910010048', 'urvishprajapati8451@gmail.com', '2005-06-09', 'Ahmedabad', '8744845121', '9716192381'),
(45, 'Rajput Swayamsinh Sanjaysinh', '22190910010049', 'swayamrajput3697@gmail.com', '2004-08-31', 'Ahmedabad', '7451118412', '9741512442'),
(46, 'Savaliya Neelkumar Jayeshbhai', '22190910010050', 'neetsavaliya3784@gmail.com', '2004-09-09', 'Ahmedabad', '9745105115', '8914512015'),
(47, 'Vadaliya Jasminkumar Hareshbhai', '22190910010051', 'jasminvadaliya6865@gmail.com', '2004-08-01', 'Ahmedabad', '8754151216', '7451121468'),
(48, 'Raval Jyotishwar Dipali', '22190910010052', 'jyotishwarraval6754@gmail.com', '2004-03-08', 'Ahmedabad', '9774561352', '9711627976'),
(49, 'test', '22190910010000', 'admin@gmail.com', '2024-04-02', 'vhvhjvhv ,m ', '9999988888', '8888899999');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `Enrollment` varchar(17) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `Stu_Name` varchar(35) DEFAULT NULL,
  `Password` varchar(20) DEFAULT NULL,
  `cfw_th` int(11) DEFAULT NULL,
  `cfw_pr` int(11) DEFAULT NULL,
  `htsd1_th` int(11) DEFAULT NULL,
  `htsd1_pr` int(11) DEFAULT NULL,
  `htsd2_th` int(11) DEFAULT NULL,
  `htsd2_pr` int(11) DEFAULT NULL,
  `ne_th` int(11) DEFAULT NULL,
  `ne_pr` int(11) DEFAULT NULL,
  `ndm_th` int(11) DEFAULT NULL,
  `ndm_pr` int(11) DEFAULT NULL,
  `cs_th` int(11) DEFAULT NULL,
  `cs_pr` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `Enrollment`, `email`, `Stu_Name`, `Password`, `cfw_th`, `cfw_pr`, `htsd1_th`, `htsd1_pr`, `htsd2_th`, `htsd2_pr`, `ne_th`, `ne_pr`, `ndm_th`, `ndm_pr`, `cs_th`, `cs_pr`) VALUES
(1, '22190910010001', 'snehaachary2410@gmail.com', 'Acharya Sneha Gauravbhai', 'sneha', 48, 46, 43, 40, 39, 49, 50, 47, 43, 37, 48, 44),
(2, '22190910010002', 'aditya658@gmail.com', 'Aditya Bhadauriya', 'aditya', 15, 25, 12, 6, 22, 10, 13, 9, 6, 28, 5, 15),
(3, '22190910010003', 'Harikishan687@gmail.com', 'Chauhan Harikishan Ramkeshwar', 'harikishan', 30, 36, 39, 34, 30, 23, 28, 29, 34, 38, 34, 40),
(4, '22190910010004', 'karanchauhan574@gmail.com', 'Chauhan Karan Rakeshbhai', 'karan', 23, 10, 15, 20, 21, 19, 17, 33, 29, 25, 21, 19),
(5, '22190910010005', 'kumkumchauham1268@gmail.com', 'Chauhan Kumkumben', 'kumkum', 28, 34, 20, 36, 37, 29, 24, 30, 36, 34, 31, 29),
(6, '22190910010006', 'ishandevani3851@gmailcom', 'Devani Ishan Mukeshbhai', 'ishan', 38, 35, 30, 31, 40, 29, 46, 47, 39, 30, 35, 34),
(7, '22190910010007', 'nidhidarva2040@gmail.com', 'Dharva Nidhi Chetankumar', 'nidhi', 28, 35, 30, 31, 30, 29, 36, 37, 39, 30, 25, 34),
(8, '22190910010008', 'janalgadhavi6981@gmail.com', 'Gadhavi Janalba Rameshdan', 'janal', 39, 45, 49, 39, 36, 42, 48, 46, 42, 49, 33, 43),
(9, '22190910010009', 'jashjadav8351@gmail.com', 'Jadav Yash Hasamukbhai', 'yash', 5, 9, 16, 17, 12, 18, 20, 22, 20, 8, 13, 16),
(10, '22190910010010', 'jiyakhobragade5872@gmail.com', 'khobragade Jiya Rahulkumar', 'jiya', 23, 10, 15, 20, 21, 19, 17, 33, 29, 25, 21, 19),
(11, '22190910010011', 'meetkhonde1502@gmail.com', 'khonde Meetkumar prakash', 'meet', 26, 23, 19, 13, 22, 24, 3, 10, 16, 19, 14, 15),
(12, '22190910010012', 'jitesh9999@gmail.com', 'khubchandani Jitesh Prakash', 'jitesh', 39, 35, 39, 29, 36, 42, 48, 46, 42, 44, 33, 43),
(13, '22190910010013', 'jaryanmakwana686@gmail.com', 'Makwana Aryan Baldevbhai', 'aryan', 13, 10, 15, 20, 11, 19, 17, 13, 9, 15, 11, 9),
(14, '22190910010014', 'parthmistri6871@gmail.com', 'Mistri Parth Ashvinkumar', 'parth', 23, 10, 15, 20, 21, 19, 17, 33, 29, 25, 21, 19),
(15, '22190910010015', 'nidhi5745@gmail.com', 'Solanki Nidhi ', 'nidhi', 23, 26, 24, 20, 13, 19, 25, 13, 30, 29, 25, 19),
(16, '22190910010016', 'amishapamchal8452@gmail.com', 'Panchal Amisha Rameshbhai', 'amisha', 39, 45, 42, 46, 48, 36, 38, 41, 47, 38, 49, 45),
(18, '22190910010017', 'krunalpanchal7885@gmail.com', 'Panchal krunal Bhadreshbhai', 'krunal', 32, 35, 29, 30, 36, 34, 31, 40, 40, 45, 38, 34),
(19, '22190910010018', 'vishakhapanchal2604@gmail.com', 'Panchal Vishakha Harshadhai', 'vishakha', 44, 40, 43, 36, 48, 36, 43, 41, 47, 46, 49, 44),
(20, '22190910010019', 'vedkumarparmar2654@gmail.com', 'Parikh Vedkumar Rameshbhai', 'ved', 15, 25, 12, 6, 22, 10, 13, 9, 6, 18, 5, 15),
(21, '22190910010024', 'jinaypatel15415@gmail.com', 'Patel Jinay Dhirajkumar', 'jinay', 23, 20, 15, 20, 21, 19, 17, 33, 29, 25, 21, 19),
(22, '22190910010025', 'kaushalpatel1352@gmail.com', 'Patel Kaushal Dineshbhai', 'kaushal', 23, 10, 15, 20, 21, 19, 17, 33, 29, 25, 23, 16),
(23, '22190910010026', 'kavanpatel7894@gmail.com', 'Patel Kavanankumar Ghanshyambhai', 'kavan', 44, 49, 50, 47, 39, 49, 46, 48, 45, 41, 40, 46),
(24, '22190910010027', 'linapatrl6872@gmail.com', 'Patle Linaben Hasmukhbhai', 'lina', 48, 46, 41, 40, 39, 49, 50, 47, 41, 37, 48, 44),
(25, '22190910010028', 'namrapatel2571@gmail.com', 'Patel Namra Sudhirbhai', 'namra', 33, 21, 15, 20, 21, 29, 17, 33, 29, 28, 21, 18),
(26, '22190910010029', 'prakrutipatel3751@gmail.com', 'Patel Prakruti Chetanbhai', 'prakruti', 23, 28, 29, 30, 35, 20, 24, 31, 26, 25, 30, 28),
(27, '22190910010030', 'umangpatel7826@gmail.com', 'Patel Umang Rajeshbhai', 'umang', 23, 28, 29, 35, 34, 30, 35, 25, 30, 31, 38, 34),
(28, '22190910010031', 'devangpatil9672@gmail.com', 'Patel Devang Ganeshbhai', 'devang', 13, 10, 15, 20, 11, 19, 17, 13, 9, 15, 11, 9),
(29, '22190910010032', 'hiteshprajati3752@gmail.com', 'Prajapati Hitesh jagadishandhra', 'hitesh', 23, 10, 15, 20, 21, 19, 17, 33, 29, 25, 21, 19),
(30, '22190910010033', 'kuldeeppramar3878@gmail.com', 'Pramar Kuldeep Jatinbhai', 'kuldeep', 33, 29, 35, 20, 21, 19, 17, 23, 29, 25, 31, 29),
(31, '22190910010034', 'harshvardhan67415@gmail.com', 'Rana Harshvardhan Sureshbhai', 'harshvardhan', 25, 20, 35, 40, 31, 29, 27, 33, 39, 35, 31, 29),
(32, '22190910010035', 'nishargraval6752@gmail.com', 'Raval Nisharg Ajaykumar', 'nisharg', 45, 49, 48, 42, 39, 40, 36, 37, 35, 32, 29, 36),
(33, '22190910010036', 'irfansaiyed6762@gmail.com', 'Saiyed Irfan Ilyas', 'irfan', 13, 30, 15, 25, 21, 19, 17, 33, 29, 25, 21, 19),
(34, '22190910010037', 'mohdamanshaikh5182@gmail.com', 'Shaikh Mohd Aman Mustak Husain', 'aman', 23, 10, 15, 20, 21, 19, 17, 33, 29, 25, 21, 19),
(35, '22190910010038', 'dimpalsolnki4746@gmail.com', 'Solanki Dimpal Kiranbhai', 'dimpal', 23, 30, 15, 20, 11, 19, 17, 13, 9, 25, 11, 29),
(36, '22190910010039', 'meetsorathiya9746@gmail.com', 'Sorathiya Meet Sureshbhai', 'meet', 23, 10, 15, 20, 21, 19, 17, 33, 29, 25, 21, 18),
(37, '22190910010040', 'dhrumisuthar3752@gmail.com', 'Suthar Dhrumi Mineshbhai', 'dhrumi', 21, 20, 25, 20, 21, 15, 17, 23, 20, 25, 21, 17),
(38, '22190910010041', 'tusharbaraiya4856@gmail.com', 'Baraiya Tushar Khodsinh', 'tushar', 9, 12, 16, 26, 20, 15, 13, 19, 16, 18, 25, 15),
(39, '22190910010042', 'hitanshidarji1294@gmail.com', 'Darji Hitanshiben Rajendrakumar', 'hitanshi', 35, 49, 48, 44, 39, 43, 36, 37, 35, 32, 39, 46),
(42, '22190910010043', 'tusharnagdev6896@gmail.com', 'Nagdev Tushar Anilkumar', 'tushar', 15, 25, 12, 6, 22, 10, 13, 9, 6, 28, 5, 15),
(43, '22190910010044', 'asthapatel8745@gmail.com', 'Patle Astha Dipakkumar', 'astha', 45, 49, 48, 42, 39, 40, 36, 37, 35, 32, 29, 36),
(44, '22190910010045', 'devpatle6752@gmail.com', 'Patle Dev Nayankumar', 'dev', 23, 10, 15, 20, 21, 19, 17, 33, 29, 25, 21, 19),
(45, '22190910010046', 'meetpatle3759@gmail.com', 'Patle Meet Manubhai', 'meet', 28, 30, 18, 30, 11, 19, 17, 13, 29, 25, 11, 19),
(46, '22190910010047', 'jyotiprajapati3751@gmail.com', 'Prajapati Jyoti Pavanbhai', 'jyoti', 23, 20, 25, 20, 21, 19, 17, 23, 29, 25, 21, 17),
(47, '22190910010048', 'urvishprajapati8451@gmail.com', 'Prajapati Urvish Satishkumar', 'urvish', 23, 10, 15, 20, 21, 19, 17, 33, 29, 25, 21, 19),
(48, '22190910010049', 'swayamrajput3697@gmail.com', 'Rajput Swayamsinh Sanjaysinh', 'swayam', 33, 30, 25, 20, 21, 19, 17, 33, 29, 25, 21, 19),
(49, '22190910010050', 'neetsavaliya3784@gmail.com', 'Savaliya Neelkumar Jayeshbhai', 'neel', 25, 15, 22, 16, 12, 17, 13, 19, 15, 20, 15, 25),
(50, '22190910010051', 'jasminvadaliya6865@gmail.com', 'Vadaliya Jasminkumar Hareshbhai', 'jasmin', 11, 15, 12, 6, 22, 10, 13, 19, 16, 18, 35, 15),
(51, '22190910010052', 'jyotishwarraval6754@gmail.com', 'Raval Jyotishwar Dipali', 'jyotishwar', 44, 49, 41, 47, 39, 49, 46, 48, 35, 41, 40, 36),
(52, '22190910010000', 'admin@gmail.com', 'test', 'admin@123', 48, 46, 41, 40, 39, 49, 50, 47, 41, 36, 48, 44);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student__c`
--
ALTER TABLE `student__c`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index_name` (`Stu_Name`,`Enrollment`,`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Stu_Name` (`Stu_Name`,`Enrollment`,`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `student__c`
--
ALTER TABLE `student__c`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`Stu_Name`,`Enrollment`,`email`) REFERENCES `student__c` (`Stu_Name`, `Enrollment`, `email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
