from flask import Flask, render_template, redirect, url_for, session, flash, request
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo
from flask_mysqldb import MySQL

import bcrypt


app = Flask(__name__)
    

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'login'
app.secret_key = 'your_secret_kry_here'


# Initialize MySQL
mysql = MySQL(app)

class RegisterForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired()])
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Register")

class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")

class ChangePasswordForm(FlaskForm):
    current_password = PasswordField("Current Password", validators=[DataRequired()])
    new_password = PasswordField("New Password", validators=[DataRequired()])
    confirm_password = PasswordField(
        "Confirm New Password", 
        validators=[DataRequired(), EqualTo('new_password', message='Passwords must match')]
    )
    submit = SubmitField("Change Password")

    

@app.route('/')
def index():
    return render_template('dashboard.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        name = form.name.data
        email = form.email.data
        password = form.password.data

        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO users (name, email, password) VALUES (%s, %s, %s)", (name, email, hashed_password))
        mysql.connection.commit()
        cursor.close()

        flash("Registration successful. Please log in.")
        return redirect(url_for('login'))
    
    return render_template('register.html', form=form)

@app.route("/login", methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        cursor.close()

        if user and user[4] == password: 
            session['user_id'] = user[0]
            session['user_email'] = form.email.data
            return redirect(url_for('dashboard'))
        else:
            flash("Login failed. Please check your email and password.")
            return redirect(url_for('login'))
        

    return render_template('login.html', form=form)

@app.route("/dashboard")
def dashboard():
    global user_email
    user_email = session.get('user_email')
  
    return render_template('dashboard.html',user_email=user_email)



@app.route("/result", methods=['GET', 'POST'])
def result():
    user_email = session.get('user_email')
    
    user_data = None          
    cursor = mysql.connection.cursor()
    try:
        # query = f"SELECT * FROM users WHERE email = {user_email}"
        # cursor.execute(query, (user_email,))
        cursor.execute("SELECT * FROM users WHERE email = %s", (user_email,))

        user_data = cursor.fetchall()
                    
    except Exception as e:
        print(f"Error fetching data from database: {e}")
    finally:
        cursor.close()
    
    return render_template('result.html', user_data=user_data)

@app.route("/profile", methods=['GET', 'POST'])
def profile():
    user_email = session.get('user_email')
    user_data = None  
        
    cursor = mysql.connection.cursor()
    try:
        
        cursor.execute("SELECT * FROM student_ _c WHERE email = %s", (user_email,))

        user_data = cursor.fetchall()
    except Exception as e:
        print(f"Error fetching data from database: {e}")
    finally:
        cursor.close()
    print(user_data)
    return render_template('profile.html', user_data=user_data)

@app.route('/change_password', methods=['GET', 'POST'])
def change_password():
    user_email = session.get('user_email')
    if not user_email:
        flash("You must be logged in to change your password.")
        return redirect(url_for('login'))

    form = ChangePasswordForm()
    email = form.email.data
    if form.validate_on_submit():
        Password = form.current_password.data
        new_password = form.new_password.data

        cursor = mysql.connection.cursor()
        cursor.execute("SELECT Password FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        cursor.close()

        # if user and bcrypt.checkpw(current_password.encode('utf-8'), user[0].encode('utf-8')):
        #     hashed_password = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt())

        cursor = mysql.connection.cursor()
        cursor.execute("UPDATE users SET Password = %s WHERE email = %s", (Password, email))
        mysql.connection.commit()
        cursor.close()

        flash("Password changed successfully!")
        return redirect(url_for('dashboard'))
    else:
        flash("Incorrect current password.")
    return render_template('passwd.html', form=form)

    
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
    # app.run(debug=True)


