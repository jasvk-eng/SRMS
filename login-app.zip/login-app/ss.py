import secrets

print(secrets.token_hex(32))  # Outputs a strong random key
# s3cr3t_k3y!@12345_random_key